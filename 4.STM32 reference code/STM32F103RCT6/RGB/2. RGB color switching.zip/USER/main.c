#include "AllHeader.h" 


int main()
{
	u16 iseed;
	SystemInit();
	NVIC_SetPriorityGrouping(NVIC_PriorityGroup_2);
	
	delay_init();
	Adc_Init();
	
	iseed= Get_Adc_Average(ADC_Channel_14,3);
	srand(iseed);
	
	ws2812_Init();
	
	ws2812_Roll_on_Color_Ring(20);
	
	while(1);
	
}

