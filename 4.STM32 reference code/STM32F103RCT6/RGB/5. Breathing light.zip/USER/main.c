#include "AllHeader.h" 


int main()
{
	u16 iseed;
	SystemInit();
	NVIC_SetPriorityGrouping(NVIC_PriorityGroup_2);
	
	delay_init();
	Adc_Init();
	
	iseed= Get_Adc_Average(ADC_Channel_14,3);
	srand(iseed);
	
	ws2812_Init();
	

	while(1)
	{ 
		ws2812_All_LED_one_Color_breath(20,C_Red); 
		
	}
	
}

