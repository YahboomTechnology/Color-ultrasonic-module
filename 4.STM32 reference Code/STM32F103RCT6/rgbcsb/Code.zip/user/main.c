#include "stm32f10x.h"
#include "bsp_ultrasonic.h"
#include "usart.h"
#include "delay.h"


int main(void)
{
	int Len = 0;
	//ultasonic_Init();
	delay_init();
	bsp_Ultrasonic_Timer3_Init();
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  uart1_init(9600); 
	printf("CSB test\n\r"); 
	while(1)
	{
	Len = bsp_getUltrasonicDistance(); 
	
	printf("CSB:%d\n\r", Len);
 delay_ms(500);  	
	
	}

}
	
