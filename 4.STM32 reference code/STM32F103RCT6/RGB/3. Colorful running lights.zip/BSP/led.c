#include "AllHeader.h" 

static void ws281x_delay(unsigned int delay_num)
{
  while(delay_num--);   
}

void ws2811_init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
 	
  RCC_APB2PeriphClockCmd(LED_RCC, ENABLE);
	
  GPIO_InitStructure.GPIO_Pin = LED_PIN;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(LED_PORT, &GPIO_InitStructure);
  GPIO_ResetBits(LED_PORT,LED_PIN);	
	
 	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);	
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOC, &GPIO_InitStructure);
  GPIO_ResetBits(GPIOC,GPIO_Pin_13);
}

static void ws281x_sendLow(void)  
{
  Send_HIGH();
  ws281x_delay(15);
  Send_LOW();
  ws281x_delay(60);
}
static void ws281x_sendHigh(void)
{
  Send_HIGH();
  ws281x_delay(60);
  Send_LOW();
  ws281x_delay(15);
}
void ws2811_Reset(void)
{ 
  Send_LOW(); 
  delay_us(200);  
  Send_HIGH();
  Send_LOW();
}

void ws281x_sendOne(uint32_t dat)   
{
  uint8_t i;
  unsigned char byte;
  for(i = 24; i > 0; i--)
  {
    byte = ((dat>>i) & 0x01);
    if(byte == 1)
    {
      ws281x_sendHigh();
    }
    else
    {
      ws281x_sendLow();
    }
  }
}


