/**
* @par Copyright (C): 2010-2019, Shenzhen Yahboom Tech
* @file         app_ultrasonic.h
* @author       liusen
* @version      V1.0
* @date         2017.07.21
* @brief        ������������ͷ�ļ�
* @details      
* @par History  ������˵��
*                 
* version:	liusen_20170717
*/

#ifndef __BSP_ULTRASONIC_H__
#define __BSP_ULTRASONIC_H__	


#define TRIG_RCC		RCC_APB2Periph_GPIOB
#define ECHO_RCC		RCC_APB2Periph_GPIOB

#define TRIG_PIN		GPIO_Pin_6
#define ECHO_PIN		GPIO_Pin_6

#define TRIG_PORT		GPIOB
#define ECHO_PORT		GPIOB


void ultasonic_Init(void);
extern float bsp_getUltrasonicDistance(void);
extern void bsp_Ultrasonic_Timer3_Init(void);


#endif



