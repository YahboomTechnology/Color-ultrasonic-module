#include "bsp_ultrasonic.h"
#include "stm32f10x.h"
#include "delay.h"


unsigned int overcount = 0;


void ultasonic_Trig(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(TRIG_RCC,ENABLE);
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin=TRIG_PIN;
	GPIO_Init(TRIG_PORT,&GPIO_InitStructure);
	GPIO_ResetBits(TRIG_PORT,TRIG_PIN);
}

void  ultasonic_Echo(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(ECHO_RCC,ENABLE);
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin=ECHO_PIN;
	GPIO_Init(ECHO_PORT,&GPIO_InitStructure);
}

float bsp_getUltrasonicDistance(void)
{
	float length = 0, sum = 0;
	u16 tim;
	unsigned int  i = 0;

	while(i != 5)
	{
		ultasonic_Trig();
		GPIO_SetBits(TRIG_PORT, TRIG_PIN);
		delay_us(20);
		GPIO_ResetBits(TRIG_PORT, TRIG_PIN);

		ultasonic_Echo();
		while(GPIO_ReadInputDataBit(ECHO_PORT, ECHO_PIN) == RESET);
		TIM_Cmd(TIM3,ENABLE);
		
		i+=1;
		while(GPIO_ReadInputDataBit(ECHO_PORT, ECHO_PIN) == SET);
		TIM_Cmd(TIM3, DISABLE);
		
		tim = TIM_GetCounter(TIM3);
		
		length = (tim + overcount * 1000) / 58.0;
		
		sum = length + sum;
		TIM3->CNT = 0;
		overcount = 0;
		delay_ms(1);
	}
	length = sum / 5;
	return length;
}


void bsp_Ultrasonic_Timer3_Init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructer;
	NVIC_InitTypeDef NVIC_InitStructer;


	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	TIM_DeInit(TIM3);
	TIM_TimeBaseInitStructer.TIM_Period = 999;
	TIM_TimeBaseInitStructer.TIM_Prescaler = 71;
	TIM_TimeBaseInitStructer.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructer.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructer);
	
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitStructer.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructer.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructer.NVIC_IRQChannel = TIM3_IRQn;
	NVIC_InitStructer.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStructer);
	TIM_Cmd(TIM3, DISABLE);

}

void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
		overcount++;	
	}
}

